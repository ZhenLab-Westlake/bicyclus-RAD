############################################################################################
$max_count = 200;
############################################################################################

$file = $ARGV[0];

open(FILE, "<$file")
	or die;

$p = 0;
while (<FILE>) {
	$line = $_; chomp($line); chop($line);
	$_ = <FILE>;
	
	($locus, $IDs) = split(/\{/,$line);
	@ID =  split(/\|/,$IDs);

	foreach (@ID) {
		($lib_ID, $seq_ID, $seq_count) = split(/\;/,$_);
		if ($seq_count > $max_count) { $seq_count = $max_count + 1; }
		$array{$lib_ID}[$seq_count]++;
	}
}
close FILE;

foreach $key (keys %array) {

	print "$key\n";
	$x = 1;
	while ($x <= $max_count + 1) {
		print "$x\t" . $array{$key}[$x] . "\n";
		$x++;
	}
	print "\n";

}



