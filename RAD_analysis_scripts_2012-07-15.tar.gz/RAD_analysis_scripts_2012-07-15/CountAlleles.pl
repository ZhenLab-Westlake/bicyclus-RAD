$loci = $ARGV[0];
$novo = $ARGV[1];

open(FILE, "<$loci") or die;

while (<FILE>) {
	$line = $_;
	chomp($line);
	if (substr($line,0,1) eq ">") {
		chop($line); ($locus, $ID) = split(/\{/,$line); $locus = substr($locus,1,length($locus));
		push(@{$locus_array{$locus}}, $ID);
	}
}
close FILE;


open(FILE, "<$novo") or die;

while (<FILE>) {
	$line = $_;
	chomp($line);
	if (substr($line,0,1) eq "@") {
		@tabs = split(/\t/,$line);
		if ($tabs[4] eq "U") {
			chop($tabs[7]); ($locus, $ID) = split(/\{/,$tabs[7]); $locus = substr($locus,1,length($locus));
			$locus_count{$locus}{$ID}++;
		}
	}
}
close FILE;


foreach $key (keys %locus_array) {
	push(@order, $key);
}
@order = sort { $a <=> $b } @order;


foreach (@order) {
	$n = 0;
	$out1 = ""; $out2 = "";

	while ($n < scalar(@{$locus_array{$_}})) {
		$ID = $locus_array{$_}[$n];
		$count = $locus_count{$_}{$ID}; if ($count eq "") { $count = 0; }
		$out1 = $out1 . "\{$ID\},";
		$out2 = $out2 . "$count,";
		$n++;
	}
	chop($out1); chop($out2); print "$_ $out1 $out2\n";
}



